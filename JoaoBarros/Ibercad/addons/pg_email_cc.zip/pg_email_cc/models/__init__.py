# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.
from . import email_cc
