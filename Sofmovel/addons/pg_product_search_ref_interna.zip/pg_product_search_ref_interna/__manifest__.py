
{
    'name': 'PG product search ref interna',
    'version': '1.0',
    'summary': 'Add  fields to cut the carpet and sell by m2.',
    'description': 'Add  fields to cut the carpet and sell by m2.',
    'depends': ['base', 'product', 'sale'], 
    'data': [],
    'installable': True, 
    'auto_install': False,               
    'application': False,    
}
