{
    "name": "PG Confirming Payment Automation",
    "version": "1.0",
    "category": "Accounting",
    "summary": "Automatiza pagamento via confirming ao publicar movimentos 'BC'",
    "depends": ["account"],
    "data": [
        "views/confirming.xml"
    ],
    "installable": True,
    "auto_install": False,
}