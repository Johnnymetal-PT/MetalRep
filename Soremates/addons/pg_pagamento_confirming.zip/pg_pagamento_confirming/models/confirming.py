from odoo import models
from odoo.exceptions import UserError

class AccountMove(models.Model):
    _inherit = 'account.move'

    def action_criar_pagamento_confirming(self):
        for move in self:
            if move.move_type != 'in_invoice':
                raise UserError("Apenas faturas de fornecedor são elegíveis para confirming.")
            if not move.x_studio_transferir_para_confirming:
                raise UserError("A opção 'Transferir para Confirming' deve estar selecionada.")
            if move.state != 'posted':
                raise UserError("A fatura deve estar publicada antes de gerar os lançamentos de diário.")

            partner = move.partner_id
            amount = sum(move.line_ids.filtered(lambda l: l.account_id.code == '221').mapped('debit'))

            if amount <= 0:
                raise UserError("O valor da fatura não é válido para confirming.")

            # Diário
            journal = self.env['account.journal'].search([('name', '=', 'Operações Confirming')], limit=1)
            if not journal:
                raise UserError("Diário 'Operações Confirming' não encontrado.")

            # Contas
            conta_221 = self.env['account.account'].search([('code', '=', '221')], limit=1)
            conta_2212 = self.env['account.account'].search([('code', '=', '2212')], limit=1)
            conta_1211 = self.env['account.account'].search([('code', '=', '1211')], limit=1)
            conta_12102 = self.env['account.account'].search([('code', '=', '12102')], limit=1)

            if not all([conta_221, conta_2212, conta_1211, conta_12102]):
                raise UserError("As contas 221, 2212, 1211 e 12102 devem estar configuradas.")

            # 🔁 1. Fornecedores → Fornecedores Confirming
            move_1 = self.env['account.move'].create({
                'ref': f"Transferência p/ Confirming - {move.name}",
                'journal_id': journal.id,
                'date': move.date,
                'line_ids': [
                    (0, 0, {
                        'name': 'Transferência de Fornecedores para Confirming',
                        'debit': 0.0,
                        'credit': amount,
                        'account_id': conta_221.id,
                        'partner_id': partner.id,
                    }),
                    (0, 0, {
                        'name': 'Entrada em Fornecedores Confirming',
                        'debit': amount,
                        'credit': 0.0,
                        'account_id': conta_2212.id,
                        'partner_id': partner.id,
                    }),
                ]
            })
            move_1.action_post()

            # 🔁 2. Fornecedores Confirming → Banco Confirming
            move_2 = self.env['account.move'].create({
                'ref': f"Pagamento Confirming Banco - {move.name}",
                'journal_id': journal.id,
                'date': move.date,
                'line_ids': [
                    (0, 0, {
                        'name': 'Pagamento Confirming para Banco',
                        'debit': 0.0,
                        'credit': amount,
                        'account_id': conta_2212.id,
                        'partner_id': partner.id,
                    }),
                    (0, 0, {
                        'name': 'Entrada no Banco Confirming',
                        'debit': amount,
                        'credit': 0.0,
                        'account_id': conta_1211.id,
                        'partner_id': partner.id,
                    }),
                ]
            })
            move_2.action_post()

            # 🔁 3. Banco Confirming → Banco CGD (draft)
            move_3 = self.env['account.move'].create({
                'ref': f"Transferência Banco Confirming → CGD - {move.name}",
                'journal_id': journal.id,
                'date': move.date,
                'line_ids': [
                    (0, 0, {
                        'name': 'Transferência p/ Banco CGD',
                        'debit': 0.0,
                        'credit': amount,
                        'account_id': conta_1211.id,
                        'partner_id': partner.id,
                    }),
                    (0, 0, {
                        'name': 'Entrada no Banco CGD',
                        'debit': amount,
                        'credit': 0.0,
                        'account_id': conta_12102.id,
                        'partner_id': partner.id,
                    }),
                ]
            })
            # Não se faz post — permanece em draft

            return {
                'name': 'Transferência Confirming Concluída',
                'type': 'ir.actions.act_window',
                'res_model': 'account.move',
                'res_id': move_3.id,
                'view_mode': 'form',
                'target': 'current',
            }

    def has_confirming_button(self):
        for rec in self:
            return rec.move_type == 'in_invoice' and rec.state == 'posted' and rec.x_studio_transferir_para_confirming
